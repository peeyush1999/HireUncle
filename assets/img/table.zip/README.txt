A Pen created at CodePen.io. You can find this one at https://codepen.io/AllThingsSmitty/pen/MyqmdM.

 This is a relatively well-known pattern for responsive tables, but it's worthwhile to give a reminder or FYI to the new folks. I've also tried to make it accessible for screen readers.