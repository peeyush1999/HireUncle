A Pen created at CodePen.io. You can find this one at http://codepen.io/hbuchel/pen/sFefL.

 Trying to solve the "Well, my developer says the list view has to be a table" issue. Trying.